process.env.POSTGRES_HOST = 'postgres';
process.env.POSTGRES_USER = 'postgres';
process.env.POSTGRES_PASSWORD = 'postgres';
process.env.POSTGRES_DB = 'postgres';
process.env.NODE_ENV = 'test'; // Füge dies hinzu, um die Testumgebung zu erkennen
process.env.PORT = 4001;
process.env.JEST_PORT = 5064;
process.env.NODE_ENV = 'test';