import React from 'react';
import './CSS/Dashboard.css';

const Dashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p>Welcome to the Admin Panel!</p>
    </div>
  );
};

export default Dashboard;
